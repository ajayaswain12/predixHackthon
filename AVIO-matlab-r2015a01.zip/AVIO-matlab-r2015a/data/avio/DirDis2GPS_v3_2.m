%1
% Calculate the final GPS coordinates
% given direction, distance in Km and
% initial GPS coordinates in degree
% Sintax: [lat_o,lon_o] = DirDis2GPS(dir,dis,lat_i,lon_i,R);
% Inputs: dir: direction in degree, e.g 0->North, 90->East, 180->South, 270->West dis: distance in kilometers lat_i/lon_i:
% Initial Latitude and Longitude in degree R: (optional) Earth radius in kilometers (default R=6378.137)
% Output: lat_o/lon_o: Final Latitude and Longitude in degree
% CODE
function [lat_o,lon_o] =DirDis2GPS_v3_2(dir,dis,lat_i,lon_i,altitude,varagin)
% Correction by adding the altitude to the earth radius
if nargin==6
R = varagin+altitude; % User-defined Earth Equatorial Radius +
aircraft altitude
else
R=(6378.137)+altitude; % Conventional Earth Equatorial Radius + aircraft altitude
end
dir=degtorad(dir);
lat_i=deg2rad(lat_i); %conversion to radians
lon_i=deg2rad(lon_i);
lat_o = asin(sin(lat_i)*cos(dis/R) + cos(lat_i)*sin(dis/R)*cos(dir)); %final latitude
lon_o = lon_i + atan2(sin(dir)*sin(dis/R)*cos(lat_i),cos(dis/R)-sin(lat_i)*sin(lat_o)); %final latitude
lat_o=rad2deg(lat_o);
lon_o=rad2deg(lon_o);
end