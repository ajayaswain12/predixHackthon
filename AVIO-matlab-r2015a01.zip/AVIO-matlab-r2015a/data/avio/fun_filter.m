
% Numerical cleaning of speeds
% matrix from errors and outliers
% Different section where different data pattern are treated:
% 1) erasing first and last 10 seconds of acquired signal if non-zero
% 2) erasing start and end of acquisition from unreal speeds values
% 3) erasing initial negative vertical velocity values
% 4) replacing with average values unreal rising edge and falling edge
% on two samples
% 5) applying third-order Savitzky-Golay filter
% CODE

function [speeds] = fun_filter(speeds)
    zer = zeros(20,1);
    speeds(:, 1) = speeds(:, 1);
    speeds(:, 2) = speeds(:, 2);
    speeds(:, 3) = -speeds(:, 3); %altitude vector assumed negative
    if ~isequal(speeds(1:20, 1), zer) || ~isequal(speeds(1:20, 2), zer) % 1
        speeds(1:20, :) = [];
    end
    if ~isequal(speeds(end - 20:end, 1), zer) || ~isequal(speeds(end - 20:end, 2), zer) % 1
        speeds(end - 20:end, :) = [];
    end
    while speeds(1, 1) ~= 0 && (speeds(1, 1) > 800 || speeds(1, 1) < -800) % 2
        speeds(1, :) = [];
    end
    while speeds(end, 1) ~= 0 && (speeds(end, 1) > 800 || speeds(end, 1) < -800) % 2
        speeds(end, :) = [];
    end
    while speeds(1, 2) ~= 0 && (speeds(1, 2) > 800 || speeds(1, 2) < -800) % 2
        speeds(1, :) = [];
    end
    while speeds(end, 2) ~= 0 && (speeds(end, 2) > 800 || speeds(end, 2) < -800) % 2
        speeds(end, :) = [];
    end
    while speeds(1, 3) < 0 % 3
        speeds(1, :) = [];
        % Numerical cleaning of speeds
        % matrix from errors and outliers 2
    end
    for k = 1:1:length(speeds(1, :)) % 4
        min_patt = min(speeds(:, k));
        max_patt = max(speeds(:, k));
        patt(:, 1) = [min_patt; 0]; % undesired patterns
        patt(:, 2) = [max_patt; 0];
        patt(:, 3) = [0; min_patt];
        patt(:, 4) = [0; max_patt];
        patt(:, 5) = [min_patt; max_patt];
        patt(:, 6) = [max_patt; min_patt];
        for p = 1:1:length(patt(1, :)) % for every pattern
            cross_corr = xcorr(patt(:, p), speeds(:, k));
            cross_corr = cross_corr(1:length(speeds(:, k)));
            [ind, ~] = find(cross_corr > 1e3);
        end
        if (~isempty(ind))
            speeds(max(ind) + 1, :) = 0;
            speeds(ind, k) = (speeds(ind + 1, k) + speeds(ind, k))/2;
            ind = [];
        end
        speeds(:, k) = sgolayfilt(speeds(:, k), 3, 13); % 5
    end
end
