package com.techm.predix.aveoaero.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * 
 * 
 * @author predix -
 */
//@XmlRootElement
public class FlightDataWrapperDTO {	
	
	List<FlightParametersDTO> flightParametersDtoList = new ArrayList<FlightParametersDTO>();
	//String flightPathData = "";
	FlightLocationDTO flightLocationDTO = new FlightLocationDTO();
	
	/**
	 * @return the flightLocationDTO
	 */
	public FlightLocationDTO getFlightLocationDTO() {
		return this.flightLocationDTO;
	}
	/**
	 * @param flightLocationDTO the flightLocationDTO to set
	 */
	public void setFlightLocationDTO(FlightLocationDTO flightLocationDTO) {
		this.flightLocationDTO = flightLocationDTO;
	}
	/**
	 * @return the flightParametersDtoList
	 */
	public List<FlightParametersDTO> getFlightParametersDtoList() {
		return this.flightParametersDtoList;
	}
	/**
	 * @param flightParametersDtoList the flightParametersDtoList to set
	 */
	public void setFlightParametersDtoList(List<FlightParametersDTO> flightParametersDtoList) {
		this.flightParametersDtoList = flightParametersDtoList;
	}
	/**
	 * @return the flightPathData
	 */
	/*public String getFlightPathData() {
		return this.flightPathData;
	}*/
	/**
	 * @param flightPathData the flightPathData to set
	 */
	/*public void setFlightPathData(String flightPathData) {
		this.flightPathData = flightPathData;
	}*/
	
	
}
