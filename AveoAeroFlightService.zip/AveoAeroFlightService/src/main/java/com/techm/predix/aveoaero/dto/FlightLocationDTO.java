package com.techm.predix.aveoaero.dto;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlRootElement;


/**
 * 
 * 
 * @author predix -
 */
@XmlRootElement
public class FlightLocationDTO {
	
	String flightPathData = "";

	/**
	 * @return the flightPathData
	 */
	public String getFlightPathData() {
		return this.flightPathData;
	}

	/**
	 * @param flightPathData the flightPathData to set
	 */
	public void setFlightPathData(String flightPathData) {
		this.flightPathData = flightPathData;
	}	
	
}
