/**
 * Renders all the widgets on the tab and triggers the datasources that are used by the widgets.
 * Customize your widgets by:
 *  - Overriding or extending widget API methods
 *  - Changing widget settings or options
 */
/* jshint unused: false */
// jshint undef:false
define(['angular',
    'sample-module','highchartsmore'
], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('DashboardCtrl', ['$scope', '$log', '$http', function ($scope, $log, $http) {
        $scope.idealUPH =120;
        $scope.actualUPH =119;
        $scope.selectedSite = '';
        $scope.selectedEquipment = '';
        $scope.selectedShift = '';
        $scope.oEEDetails = '';

        //Get OEE data form service
        $scope.getData = function(){
            console.log($scope.selectedSite+' :'+$scope.selectedEquipment+' :'+$scope.selectedShift);
            if($scope.selectedSite !=='' && $scope.selectedEquipment !=='' && $scope.selectedShift !==''){
                $http.get('http://predix-alarmservice-sapan-km.grc-apps.svc.ice.ge.com/getEquipmentOEEDetailsWithParam/'+$scope.selectedSite+'/'+$scope.selectedEquipment+'/'+$scope.selectedShift)
                .success(function(data, status, headers, config) {
                    if(typeof data[0]!== undefined || data[0] !== null){
                        $scope.oEEDetails = data[0];
                    }
                    else{
                        $scope.oEEDetails = '';
                    }
                })
                .error(function(data) {
                    console.log(data);
                });
            }
            else{
                $scope.oEEDetails = '';
            }

        };
        setInterval($scope.getData, 1000);
     

        // Gauge
        var oEEGauge1=new Highcharts.Chart({
            chart: {
                    renderTo: 'oEEGauge1',
                    type: 'gauge',
                    plotBackgroundColor: null,
                    plotBackgroundImage: null,
                    plotBorderWidth: 0,
                    plotShadow: false
                },
                credits: {
                    enabled: false
                },
                annotationsOptions : {
                    enabledButtons: false
                },
                title: {
                    text: 'OEE(%)',
                },

                pane: {
                    startAngle: -140,
                    endAngle: 140,
                    background: [{
                        backgroundColor: {
                            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                            stops: [
                                [0, '#FFF'],
                                [1, '#333']
                            ]
                        },
                        borderWidth: 0,
                        outerRadius: '109%'
                    }, {
                        backgroundColor: {
                            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                            stops: [
                                [0, '#333'],
                                [1, '#FFF']
                            ]
                        },
                        borderWidth: 1,
                        outerRadius: '106%'
                    }, {
                        // default background
                    }, {
                        backgroundColor: '#DDD',
                        borderWidth: 0,
                        outerRadius: '105%',
                        innerRadius: '90%'
                    }]
                },

                // the value axis
                yAxis: {
                    min: 0,
                    max: 100,

                    minorTickInterval: 'auto',
                    minorTickWidth: 1,
                    minorTickLength: 10,
                    minorTickPosition: 'inside',
                    minorTickColor: '#666',

                    tickPixelInterval: 30,
                    tickWidth: 2,
                    tickPosition: 'inside',
                    tickLength: 10,
                    tickColor: '#666',
                    labels: {
                        step: 2,
                        rotation: 'auto'
                    },
                    title: {
                        text: ''
                    },
                    plotBands: [{
                        from: 0,
                        to: 55,
                        color: '#DF5353', // green
                        
                    }, {
                        from: 55,
                        to: 75,
                        color: '#DDDF0D', // yellow
                        
                    }, {
                        from: 75,
                        to: 100,
                        color: '#55BF3B', // red
                        
                    }]
                },

                series: [{
                    name: 'OEE',
                    data: [0],
                    tooltip: {
                        valueSuffix: ' %'
                    }
                }]

            },
            // Add some life
            function (chart) {
                if (!chart.renderer.forExport) {
                    setInterval(function () {
                        var point = chart.series[0].points[0],
                            newVal;
                       
                        if(typeof $scope.oEEDetails !== 'undefined' && $scope.oEEDetails!==''){
                            console.log('undrfined in side if:'+$scope.oEEDetails);
                            newVal = $scope.oEEDetails.oeeCalc;
                        }
                        else
                        {
                            console.log('undrfined in side else if:'+$scope.oEEDetails);
                            newVal = 0;
                        }
                        
                        point.update(newVal);

                    }, 1000);
                }
            });
            
        //gauge 2
        var availGauge2 = new Highcharts.Chart({
            chart: {
                renderTo: 'availGauge2',
                type: 'gauge',
                plotBackgroundColor: null,
                plotBackgroundImage: null,
                plotBorderWidth: 0,
                plotShadow: false
            },
            credits: {
                enabled: false
            },
            title: {
                text: 'Avaibility(%)',
            },
            annotationsOptions : {
                enabledButtons: false
            },
            pane: {
                startAngle: -140,
                endAngle: 140,
                background: [{
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#FFF'],
                            [1, '#333']
                        ]
                    },
                    borderWidth: 0,
                    outerRadius: '89%'
                }, {
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#333'],
                            [1, '#FFF']
                        ]
                    },
                    borderWidth: 1,
                    outerRadius: '86%'
                }, {
                    // default background
                }, {
                    backgroundColor: '#DDD',
                    borderWidth: 0,
                    outerRadius: '90%',
                    innerRadius: '85%'
                }]
            },

            // the value axis
            yAxis: {
                min: 0,
                max: 100,

                minorTickInterval: 'auto',
                minorTickWidth: 1,
                minorTickLength: 10,
                minorTickPosition: 'inside',
                minorTickColor: '#666',

                tickPixelInterval: 30,
                tickWidth: 2,
                tickPosition: 'inside',
                tickLength: 10,
                tickColor: '#666',
                labels: {
                    step: 2,
                    rotation: 'auto'
                },
                title: {
                    text: ''
                },
                plotBands: [{
                    from: 0,
                    to: 55,
                    //color: '#DF5353', // green
                    
                }, {
                    from: 55,
                    to: 75,
                    //color: '#DDDF0D', // yellow
                    
                }, {
                    from: 75,
                    to: 100,
                    //color: '#55BF3B', // red
                    
                }]
            },

            series: [{
                name: 'Avaibility',
                data: [0],
                tooltip: {
                    valueSuffix: ' %'
                }
            }]

        },
            // Add some life
        function (chart) {
            if (!chart.renderer.forExport) {
                setInterval(function () {
                    var point = chart.series[0].points[0],
                        newVal;

                    if(typeof $scope.oEEDetails !== 'undefined' && $scope.oEEDetails !== ''){
                        newVal = $scope.oEEDetails.availability * 100;
                    }
                    else
                    {
                        newVal = 0;
                    }
                    console.log(newVal);
                    point.update(newVal);
                    

                }, 1000);
            }
        });
        
        //gauge 3
        var perfGauge3 = new Highcharts.Chart({
            chart: {
                renderTo: 'perfGauge3',
                type: 'gauge',
                plotBackgroundColor: null,
                plotBackgroundImage: null,
                plotBorderWidth: 0,
                plotShadow: false
            },
            credits: {
                enabled: false
            },
            title: {
                text: 'Performance(%)',
            },
            annotationsOptions : {
                enabledButtons: false
            },
            pane: {
                startAngle: -140,
                endAngle: 140,
                background: [{
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#FFF'],
                            [1, '#333']
                        ]
                    },
                    borderWidth: 0,
                    outerRadius: '89%'
                }, {
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#333'],
                            [1, '#FFF']
                        ]
                    },
                    borderWidth: 1,
                    outerRadius: '86%'
                }, {
                    // default background
                }, {
                    backgroundColor: '#DDD',
                    borderWidth: 0,
                    outerRadius: '90%',
                    innerRadius: '85%'
                }]
            },

            // the value axis
            yAxis: {
                min: 0,
                max: 100,

                minorTickInterval: 'auto',
                minorTickWidth: 1,
                minorTickLength: 10,
                minorTickPosition: 'inside',
                minorTickColor: '#666',

                tickPixelInterval: 30,
                tickWidth: 2,
                tickPosition: 'inside',
                tickLength: 10,
                tickColor: '#666',
                labels: {
                    step: 2,
                    rotation: 'auto'
                },
                title: {
                    text: ''
                },
                plotBands: [{
                    from: 0,
                    to: 55,
                    //color: '#DF5353', // green
                    
                }, {
                    from: 55,
                    to: 75,
                    //color: '#DDDF0D', // yellow
                    
                }, {
                    from: 75,
                    to: 100,
                    //color: '#55BF3B', // red
                    
                }]
            },

            series: [{
                name: 'Performance',
                data: [0],
                tooltip: {
                    valueSuffix: ' %'
                }
            }]

        },
            // Add some life
        function (chart) {
            if (!chart.renderer.forExport) {
                setInterval(function () {
                    var point = chart.series[0].points[0],
                        newVal;
                    
                    if(typeof $scope.oEEDetails !== 'undefined' && $scope.oEEDetails !== ''){
                        newVal = $scope.oEEDetails.performanceSpeedLoss * 100;
                    }
                    else
                    {
                        newVal = 0;
                    }
                    console.log(newVal);
                    point.update(newVal);

                }, 1000);
            }
        });

        //gauge 4
        var qualGauge4 = new Highcharts.Chart({
            chart: {
                renderTo: 'qualGauge4',
                type: 'gauge',
                plotBackgroundColor: null,
                plotBackgroundImage: null,
                plotBorderWidth: 0,
                plotShadow: false
            },
            credits: {
                enabled: false
            },
            annotationsOptions : {
                enabledButtons: false
            },
            /*exporting: {
                buttons: {
                    contextButtons: {
                        enabled: false
                    }
                    
                }
            },*/
            title: {
                text: 'Quality(%)',
            },

            pane: {
                startAngle: -140,
                endAngle: 140,
                background: [{
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#FFF'],
                            [1, '#333']
                        ]
                    },
                    borderWidth: 0,
                    outerRadius: '89%'
                }, {
                    backgroundColor: {
                        linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                        stops: [
                            [0, '#333'],
                            [1, '#FFF']
                        ]
                    },
                    borderWidth: 1,
                    outerRadius: '86%'
                }, {
                    // default background
                }, {
                    backgroundColor: '#DDD',
                    borderWidth: 0,
                    outerRadius: '90%',
                    innerRadius: '85%'
                }]
            },

            // the value axis
            yAxis: {
                min: 0,
                max: 100,

                minorTickInterval: 'auto',
                minorTickWidth: 1,
                minorTickLength: 10,
                minorTickPosition: 'inside',
                minorTickColor: '#666',

                tickPixelInterval: 30,
                tickWidth: 2,
                tickPosition: 'inside',
                tickLength: 10,
                tickColor: '#666',
                labels: {
                    step: 2,
                    rotation: 'auto'
                },
                title: {
                    text: ''
                },
                plotBands: [{
                    from: 0,
                    to: 55,
                    //color: '#DF5353', // green
                    
                }, {
                    from: 55,
                    to: 75,
                    //color: '#DDDF0D', // yellow
                    
                }, {
                    from: 75,
                    to: 100,
                    //color: '#55BF3B', // red
                    
                }]
            },

            series: [{
                name: 'Quality',
                data: [0],
                tooltip: {
                    valueSuffix: ' %'
                }
            }]

        },
            // Add some life
        function (chart) {
            if (!chart.renderer.forExport) {
                setInterval(function () {
                    var point = chart.series[0].points[0],
                        newVal;
                    if(typeof $scope.oEEDetails !== 'undefined' && $scope.oEEDetails !== ''){
                        newVal = $scope.oEEDetails.qualityCalc;
                    }
                    else
                    {
                        newVal = 0;
                    }
                    console.log(newVal);
                    point.update(newVal);

                }, 1000);
            }
        });
    // Gauge end


    //linear gauges
        (function (H) {
                var defaultPlotOptions = H.getOptions().plotOptions,
                    columnType = H.seriesTypes.column,
                    wrap = H.wrap,
                    each = H.each;

                defaultPlotOptions.lineargauge = H.merge(defaultPlotOptions.column, {});
                H.seriesTypes.lineargauge = H.extendClass(columnType, {
                    type: 'lineargauge',
                    //inverted: true,
                    setVisible: function () {
                        columnType.prototype.setVisible.apply(this, arguments);
                        if (this.markLine) {
                            this.markLine[this.visible ? 'show' : 'hide']();
                        }
                    },
                    drawPoints: function () {
                        // Draw the Column like always
                        columnType.prototype.drawPoints.apply(this, arguments);

                        // Add a Marker
                        var series = this,
                            chart = this.chart,
                            inverted = chart.inverted,
                            xAxis = this.xAxis,
                            yAxis = this.yAxis,
                            point = this.points[0], // we know there is only 1 point
                            markLine = this.markLine,
                            ani = markLine ? 'animate' : 'attr';

                        // Hide column
                        point.graphic.hide();

                        if (!markLine) {
                            var path = inverted ? ['M', 0, 0, 'L', -5, -5, 'L', 5, -5, 'L', 0, 0, 'L', 0, 0 + xAxis.len] : ['M', 0, 0, 'L', -5, -5, 'L', -5, 5,'L', 0, 0, 'L', xAxis.len, 0];
                            markLine = this.markLine = chart.renderer.path(path)
                                .attr({
                                    'fill': series.color,
                                    'stroke': series.color,
                                    'stroke-width': 1
                                }).add();
                        }
                        markLine[ani]({
                            translateX: inverted ? xAxis.left + yAxis.translate(point.y) : xAxis.left,
                            translateY: inverted ? xAxis.top : yAxis.top + yAxis.len -  yAxis.translate(point.y)
                        });
                    }
                });
            }(Highcharts));

        var oEELnGauge1 = new Highcharts.Chart({
            chart: {
                renderTo: 'oEELnGauge1',
                type: 'lineargauge',
                //backgroundColor: '#D3D3D3',
                inverted: true
            },
            credits: {
                enabled: false
            },
            annotationsOptions : {
                enabledButtons: false
            },

            title: {
                text: 'OEE'
            },
            xAxis: {
                lineColor: '#C0C0C0',
                labels: {
                    enabled: false
                },
                tickLength: 0
            },
            yAxis: {
                min: 0,
                max: 100,
                tickLength: 5,
                tickWidth: 1,
                tickColor: '#C0C0C0',
                gridLineColor: '#C0C0C0',
                gridLineWidth: 1,
                minorTickInterval: 5,
                minorTickWidth: 1,
                minorTickLength: 5,
                minorGridLineWidth: 0,

                title: '',
                labels: {
                    format: '{value}'
                },
                plotBands: [{
                    from: 0,
                    to: 40,
                    color: '#DF5353'
                }, {
                    from: 40,
                    to: 80,
                    color: '#DDDF0D'
                }, {
                    from: 80,
                    to: 100,
                    color: '#55BF3B'
                }]
            },
            legend: {
                enabled: false
            },

            series: [{
                data: [92],
                color: '#000',
                dataLabels: {
                    enabled: true,
                    align: 'center',
                    format: '{point.y}',
                },
                name: 'OEE: '
            }]

        }, // Add some life
        function (chart) {
            setInterval(function () {
                Highcharts.each(chart.series, function (serie) {
                    var point = serie.points[0],
                        newVal,
                        inc = (Math.random() - 0.5) * 20;

                    newVal = point.y + inc;
                    if (newVal < 0 || newVal > 100) {
                        newVal = point.y - inc;
                    }

                    point.update(Math.floor(newVal));
                });
            }, 2000);

        });

        var availLnGauge2 = new Highcharts.Chart({
            chart: {
                renderTo: 'availLnGauge2',
                type: 'lineargauge',
                inverted: true
            },
            credits: {
                enabled: false
            },
            annotationsOptions : {
                enabledButtons: false
            },

            title: {
                text: 'Avaibility'
            },
            xAxis: {
                lineColor: '#C0C0C0',
                labels: {
                    enabled: false
                },
                tickLength: 0
            },
            yAxis: {
                min: 0,
                max: 100,
                tickLength: 5,
                tickWidth: 1,
                tickColor: '#C0C0C0',
                gridLineColor: '#C0C0C0',
                gridLineWidth: 1,
                minorTickInterval: 5,
                minorTickWidth: 1,
                minorTickLength: 5,
                minorGridLineWidth: 0,

                title: '',
                labels: {
                    format: '{value}'
                },
                plotBands: [{
                    from: 0,
                    to: 40,
                    color: '#DF5353'
                }, {
                    from: 40,
                    to: 80,
                    color: '#DDDF0D'
                }, {
                    from: 80,
                    to: 100,
                    color: '#55BF3B'
                }]
            },
            legend: {
                enabled: false
            },

            series: [{
                data: [92],
                color: '#000000',
                dataLabels: {
                    enabled: true,
                    align: 'center',
                    format: '{point.y}%',
                    y: 10
                }
            }]

        }, // Add some life
        function (chart) {
            setInterval(function () {
                Highcharts.each(chart.series, function (serie) {
                    var point = serie.points[0],
                        newVal,
                        inc = (Math.random() - 0.5) * 20;

                    newVal = point.y + inc;
                    if (newVal < 0 || newVal > 100) {
                        newVal = point.y - inc;
                    }

                    point.update(Math.floor(newVal));
                });
            }, 2000);

        });

        var perfLnGauge3 = new Highcharts.Chart({
            chart: {
                renderTo: 'perfLnGauge3',
                type: 'lineargauge',
                inverted: true
            },
            credits: {
                enabled: false
            },
            annotationsOptions : {
                enabledButtons: false
            },

            title: {
                text: 'Performance'
            },
            xAxis: {
                lineColor: '#C0C0C0',
                labels: {
                    enabled: false
                },
                tickLength: 0
            },
            yAxis: {
                min: 0,
                max: 100,
                tickLength: 5,
                tickWidth: 1,
                tickColor: '#C0C0C0',
                gridLineColor: '#C0C0C0',
                gridLineWidth: 1,
                minorTickInterval: 5,
                minorTickWidth: 1,
                minorTickLength: 5,
                minorGridLineWidth: 0,

                title: '',
                labels: {
                    format: '{value}'
                },
                plotBands: [{
                    from: 0,
                    to: 40,
                    color: '#DF5353'
                }, {
                    from: 40,
                    to: 80,
                    color: '#DDDF0D'
                }, {
                    from: 80,
                    to: 100,
                    color: '#55BF3B'
                }]
            },
            legend: {
                enabled: false
            },

            series: [{
                data: [92],
                color: '#000000',
                dataLabels: {
                    enabled: true,
                    align: 'center',
                    format: '{point.y}%',
                    y: 10
                }
            }]

        }, // Add some life
        function (chart) {
            setInterval(function () {
                Highcharts.each(chart.series, function (serie) {
                    var point = serie.points[0],
                        newVal,
                        inc = (Math.random() - 0.5) * 20;

                    newVal = point.y + inc;
                    if (newVal < 0 || newVal > 100) {
                        newVal = point.y - inc;
                    }

                    point.update(Math.floor(newVal));
                });
            }, 2000);

        });

        var qualLnGauge4 = new Highcharts.Chart({
            chart: {
                renderTo: 'qualLnGauge4',
                type: 'lineargauge',
                inverted: true
            },
            credits: {
                enabled: false
            },
            annotationsOptions : {
                enabledButtons: false
            },

            title: {
                text: 'Quality'
            },
            xAxis: {
                lineColor: '#C0C0C0',
                labels: {
                    enabled: false
                },
                tickLength: 0
            },
            yAxis: {
                min: 0,
                max: 100,
                tickLength: 5,
                tickWidth: 1,
                tickColor: '#C0C0C0',
                gridLineColor: '#C0C0C0',
                gridLineWidth: 1,
                minorTickInterval: 5,
                minorTickWidth: 1,
                minorTickLength: 5,
                minorGridLineWidth: 0,

                title: '',
                labels: {
                    format: '{value}'
                },
                plotBands: [{
                    from: 0,
                    to: 40,
                    color: '#DF5353'
                }, {
                    from: 40,
                    to: 80,
                    color: '#DDDF0D'
                }, {
                    from: 80,
                    to: 100,
                    color: '#55BF3B'
                }]
            },
            legend: {
                enabled: false
            },

            series: [{
                data: [92],
                color: '#000',
                dataLabels: {
                    enabled: true,
                    align: 'center',
                    format: '{point.y}%',
                    y: 10
                }
            }]

        }, // Add some life
        function (chart) {
            setInterval(function () {
                Highcharts.each(chart.series, function (serie) {
                    var point = serie.points[0],
                        newVal,
                        inc = (Math.random() - 0.5) * 20;

                    newVal = point.y + inc;
                    if (newVal < 0 || newVal > 100) {
                        newVal = point.y - inc;
                    }

                    point.update(Math.floor(newVal));
                });
            }, 2000);

        });


    }]);
});
