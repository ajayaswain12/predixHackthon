/**
 * Renders all the widgets on the tab and triggers the datasources that are used by the widgets.
 * Customize your widgets by:
 *  - Overriding or extending widget API methods
 *  - Changing widget settings or options
 */
/* jshint unused: false */
// jshint undef:false
define(['angular',
    'sample-module'
], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('FISDashboardCtrl', ['$scope', '$log', '$http', function ($scope, $log, $http) {
        /*var pageHeight = screen.height;
        var tableHeight = (pageHeight/2);
        alert(tableHeight);
        jQuery('#individualDetail1').css({ maxHeight: tableHeight + 'px' });
        jQuery('#individualDetail2').css({ maxHeight: tableHeight + 'px' });*/
        /*jQuery('#overallDetails').height(jQuery(document).height());
        //jQuery('#overallDetails').css({ height: divHeight + 'px' });
        jQuery('#overallDetail').css({ height: divHeight + 'px' });
        jQuery('#apiLaundry').css({ height: divHeight + 'px' });
        jQuery('#apiFabrication').css({ height: divHeight + 'px' });*/
        $scope.showOverall=true;
        $scope.specificTable=function(){
            $scope.showOverall=false;
        };
        $scope.overallTable=function(){
            $scope.showOverall=true;
        };
    }]);
});
