define(['./fis-dashboard','./dashboard', './sv-dashboard'], function() {

});
