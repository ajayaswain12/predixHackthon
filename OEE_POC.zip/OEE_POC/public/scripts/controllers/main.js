define(['./dashboard', './sv-dashboard'], function() {

});
