/* jshint unused:false */
define(['angular-mocks', 'app'], function(mocks, app) {
    'use strict';

    beforeEach(module('predixApp'));
    describe('sample-directive', function() {
        it('should ...', function() {

        });
    });
});
