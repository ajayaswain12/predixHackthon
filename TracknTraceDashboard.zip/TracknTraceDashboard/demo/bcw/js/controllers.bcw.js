'use strict';

/**
 * BCW Demo controllers. To remove when used in real app
 */

/**
 * Each demo page may have a global controller to collect demo data in one place
 */

appControllers.controller('AssetDetailsController', ['$scope', 'scriptLoader', '$http', '$stateParams', '$location', function($scope, scriptLoader,$http,$stateParams, $location){

    //var server = 'http://192.168.1.32';
    // var server = 'http://backend.dev.suite.bosch-si.com';
    var server = 'http://172.23.56.247';
    var port = '3000';
    var positionSocketPort = '4001';
    var tighteningSocketPort = '4002';

    var positionSocket = io.connect(server+':'+positionSocketPort);
    var tighteningSocket = io.connect(server+':'+tighteningSocketPort);

    var height = document.getElementById('livetracking-map');

    tighteningSocket.on('nutrunner:tighteningProcess:'+$stateParams.child, function(data){
        console.log(data);
        $scope.$apply(function(){
            var tighteningSteps = data.data["tightening steps"];
            $scope.processData = angleValues(tighteningSteps);
        });
    });
    tighteningSocket.on('nutrunner:tighteningResult:'+$stateParams.child, function(data){
        $scope.$apply(function(){
            $scope.tightenings.unshift(data.data);
			console.log($scope.nutrunner.asset.serialNo);
        });
    });

    tighteningSocket.on('backup', function (data) {
        console.log('backup received');
        $scope.$apply(function(){
            var tighteningSteps = data.data["tightening steps"];
            var length = tighteningSteps.length;

            $scope.tightenings[0].angle = tighteningSteps[length-1].angle;
            $scope.tightenings[0].torque = tighteningSteps[length-1].torque;
            for (var i=0; i<=tighteningSteps.length; i++){

            }

            $scope.processData = angleValues(tighteningSteps);
            $scope.tightenings[0].tighteningStatus = data.data["result"];
            $scope.tightenings[0].tighteningId = $scope.tightenings[0].tighteningId + 1;
            $scope.tightenings[0].tighteningProgramNumber = '0';

            var d = new Date();
            var n = d.getTime();
            $scope.tightenings[0].timestamp = n;
        });
    });

    tighteningSocket.on('notifications:'+$stateParams.child, function(data){
        $scope.$apply(function(){
            $scope.notifications = data.data;
            console.log(data.data);
        });
    });

    positionSocket.on('assets:lifecycleUpdate', function(data){
        console.log("Livecycle Update Received:");
        console.log(data);
        if ($scope.nutrunner.asset._id == data.assetId) {
            $scope.$apply(function(){            
                $scope.nutrunner.asset.status = data.data.status;
                $scope.nutrunner.asset.connection = data.data.connection;
                if ($scope.nutrunner.asset.status == 'Ready') {
                    $scope.toggleStatus = 'deactivate'
                } else if ($scope.nutrunner.asset.status == 'Unknown')
				{$scope.toggleStatus = 'offline'
				}else if ($scope.nutrunner.asset.status == 'Deactivated'){
				$scope.toggleStatus = 'activate';
				}
            });
        }
    });
    positionSocket.on('assets:positionUpdate', function(data){
        $scope.$apply(function(){
            /* your stuff goes here*/
            console.log("Position Update Received:");
            console.log(data);
            $scope.nutrunner.asset.latestPosition.x = data.data.x;
            $scope.nutrunner.asset.latestPosition.y = data.data.y;
            $scope.nutrunner.asset.latestPosition.zone = data.data.zone;

            $scope.positionStyle = {
                'position':'absolute',
                'top': $scope.nutrunner.asset.latestPosition.y+'px',
                'left': $scope.nutrunner.asset.latestPosition.x+'px',
                'width': '32px'
            }
        });
    });

    $scope.positionUpdate = function(nutrunner,x,y,zone) {
        var asset = nutrunner.asset;
        asset.latestPosition.x = x;
        asset.latestPosition.y = y;
        asset.latestPosition.zone = zone;
        asset.latestPosition.updated = new Date().getTime();

        $http.put(server+':'+port+'/assets/'+asset._id, asset).
            success(function(status) {
                console.log(status)

            }).
            error(function(error) {
                console.log(error)
            });
    }

    $scope.toggleNutrunner = function(value) {

        $http.post(server+':'+port+'/nutrunners/'+$stateParams.child+'/'+$scope.toggleStatus, {msg:''}).
            success(function(status) {
                // this callback will be called asynchronously
                // when the response is available
                console.log(status)
                if (value == 'deactivate') $scope.toggleStatus = 'activate'
                else $scope.toggleStatus = 'deactivate'
            }).
            error(function(error) {
                // called asynchronously if an error occurs
                // or server returns response with an error status.
                console.log(error)
            });
    }

    $scope.findOneNutrunner = function() {

         /*$http.get(server+':'+port+'/nutrunners/'+$stateParams.child)*/
         $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getMachineDeviceDetails/'+$stateParams.child)
         .success(function (response) {
         /*$scope.nutrunner = response;*/
        	 $scope.nutrunner = response[0];
        	 $scope.tightenings = response;
             $scope.lasttightening = response[0];
             /*alert($scope.tightenings[0].tighteningstatus);*/
             $scope.positionStyle = {
                 'position':'absolute',
                 'top': $scope.nutrunner.y+'px',
                 'left': $scope.nutrunner.x+'px',
                 'width': '32px'
             };

            $scope.nutrunnerIsActive = false;
                 if ($scope.nutrunner.status == 'Ready'){
                     $scope.nutrunnerIsActive = true
                     $scope.toggleStatus = 'deactivate';
                 }
                 else if ($scope.nutrunner.status == 'Unknown'){
				 $scope.toggleStatus = 'offline';
				 }
				 else if ($scope.nutrunner.status == 'Deactivated'){
                     $scope.nutrunnerIsActive = false;
                     $scope.toggleStatus = 'activate';
                 }
                 

         })
         .error(function () {
         $scope.error = 'could not load nutrunners.';
         });

        $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getMachineDataByDeviceId/12')
            .success(function (response) {
                $scope.tighteningCurve = response[0];
                var tighteningSteps = $scope.tighteningCurve["tightening steps"];
                console.log("Curve Found---"+tighteningSteps);
                $scope.processData = angleValues(tighteningSteps);

            })
            .error(function () {
                $scope.error = 'could not load tightening.';
            });

        /*$http.get(server+':'+port+'/nutrunners/'+$stateParams.child+'/tightenings')
            .success(function (response) {
                $scope.tightenings = response;
                $scope.lasttightening = response[0];
                console.log(response[0]);
            })
            .error(function () {
                $scope.error = 'could not load tightening.';
            });
*/
    }

    function angleValues(curve) {

        var graphData = [];
        // var angleGraph = [];
        // var torqueGraph = [];
        var programCount = curve.length;
      //  console.log("My curve---"+curve);

        for (var j = 0; j < programCount; j++) {
            var anglevalues = curve[j].graph["angle values"];
            var torquevalues = curve[j].graph["torque values"];
            var timevalues = curve[j].graph["time values"];

            //Data is represented as an array of {x,y} pairs.
            for (var i = 0; i < anglevalues.length; i++) {
                graphData.push({x: anglevalues[i], y: torquevalues[i]});
            }
        }

        //Line chart data should be sent as an array of series objects.

        return [
            {
                values: graphData,      //values - represents the array of {x,y} data points
                key: 'Torque (Nm)', //key  - the name of the series.
                color: '#ff7f0e'  //color - optional: choose your own line color.
            }
        ];

        // return processedData;
    }

    $scope.applyChartData = function(){

        $scope.processChart = nv.models.lineChart()
            .useInteractiveGuideline(true)
            .margin({left: 28, bottom: 30, right: 0})
            .color(['#82DFD6', '#ddd']);

        $scope.processChart.xAxis
            //.axisLabel('Angle (°)')
            .showMaxMin(false)
            .ticks(1000);
            //.tickFormat(function(d) { return d3.time.format('%b %d')(new Date(d)) });

        $scope.processChart.yAxis
            .axisLabel('Torque (Nm)')
            .showMaxMin(false)
            .ticks(4);
            //.tickFormat(d3.format(',f'));
    }
    $scope.loadCurve = function(id) {
        $http.get(server+':'+port+'/nutrunners/'+$stateParams.child+'/tightenings/'+id+'/curve')
            .success(function (response) {
                console.log(response);
                $scope.tighteningCurve = response["tightening steps"];
                $scope.processData = angleValues($scope.tighteningCurve);
            })
            .error(function () {
                $scope.error = 'could not load tightening.';
            });
    }
    $scope.backupCurve = function (id) {

        $http.get(server+':'+port+'/nutrunners/'+$stateParams.child+'/tightenings/'+id+'/backup')
            .success(function (response) {
                console.log('backup requested');
                console.log(response);
            })
            .error(function () {
                $scope.error = 'could not load tightening.';
                console.log($scope.error);
            });
    }

    $scope.geoFenceToggle = function (nutrunner) {
        if ($scope.toggleStatus == 'activate') {
            $scope.positionUpdate(nutrunner,'350', '98','Assembly');
            $scope.toggleNutrunner($scope.toggleStatus);

        } else if ($scope.toggleStatus  == 'deactivate') {
            $scope.positionUpdate(nutrunner,'281', '102','No Tools');
            $scope.toggleNutrunner($scope.toggleStatus);
        } else {
            console.log('wrong status: ' + $scope.toggleStatus);
        }
    }

    scriptLoader.loadScripts([
        'vendor/d3/d3.min.js',
        'vendor/nvd3/nv.d3.min.js'
    ])
        .then(function(){
            $scope.applyChartData()
        });


}]);

    /**
 * charts page controller
 */
appControllers.controller('DashboardController', ['$scope', 'scriptLoader', '$http', '$stateParams', '$location', function($scope, scriptLoader,$http,$stateParams, $location){

    // var server = 'http://192.168.1.32';
   // var server = 'http://backend.dev.suite.bosch-si.com';
	var server = 'http://localhost';
    var port = '3000';

    $scope.notificationLimit = 5;
    var tighteningSocketPort = '4002';
    var tighteningSocket = io.connect(server+':'+tighteningSocketPort);

    var positionSocketPort = '4001';
    var positionSocket = io.connect(server+':'+positionSocketPort);

    var positionSocket = io.connect(server+':'+positionSocketPort);
    positionSocket.on('assets:lifecycleUpdate', function(data){
        if ($scope.nutrunners != null) {
            var i;
            for (i=0;i<$scope.nutrunners.length;i++){
                if ($scope.nutrunners[i].asset._id == data.assetId) {
                    $scope.$apply(function(){
                        $scope.nutrunners[i].asset.status = data.data.status;
                        $scope.nutrunners[i].asset.connection = data.data.connection;
                    });
                }
            }
        }
    });

    positionSocket.on('notifications', function(data){
        $scope.$apply(function(){
            $scope.notifications.unshift(data.data);
        });
    });
    tighteningSocket.on('notifications', function(data){
        $scope.$apply(function(){
            console.log(data.data);
            if (data.data.type == 'Tightening'){
                $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getMachineResult')
                    .success(function (response) {
                       /* $scope.quality = response;
                        $scope.ok = Number(response.OK);
                        $scope.nok = Number(response.NOK);
                        $scope.results = Number(response.results);*/

                        $scope.totalquality = (response.totalQuality)*100;

                    })
                    .error(function () {
                        $scope.error = 'could not load quality kpi.';
                    });
            }
            $scope.notifications.unshift(data.data);
        });
    });
    $scope.init = function () {

        $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getMachineResult')
            .success(function (response) {
                /*$scope.quality = response;
                $scope.ok = Number(response.OK);
                $scope.nok = Number(response.NOK);
                $scope.results = Number(response.results);*/

                /*$scope.totalquality = ($scope.ok/$scope.results)*100;*/
            	$scope.totalquality = (response.totalQuality)*100;

            })
            .error(function () {
                $scope.error = 'could not load quality kpi.';
            });

        $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getToolFeetCount')
            .success(function (response) {
                $scope.nutrunners = response;
            })
            .error(function () {
                $scope.error = 'could not load nutrunners.';
            });
        $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getTighteningProcessingCount')
        .success(function (response) {
            $scope.tighteningProcess = response;
        })
        .error(function () {
            $scope.error = 'could not load tighteningProcess.';
        });
        
        $http.get(server+':'+port+'/assets')
            .success(function (response) {
                $scope.assets = response;
                var i;
                var online = 0;
                for (i=0; i<$scope.assets.length; i++) {
                    if ($scope.assets[i].connection == 'Online') online++
                }
                $scope.assetsOnline = Number(online);
                $scope.onlinePercentage = ($scope.assetsOnline/$scope.assets.length)*100;

            })
            .error(function () {
                $scope.error = 'could not load assets.';
            });
        //Code added by us
        $scope.findNutrunners();

    }
    $scope.findNutrunners = function() {
        $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getMachineDevice')
            .success(function (response) {
                $scope.nutrunners = response;
            })
            .error(function () {
                $scope.error = 'could not load nutrunners.';
            });
    }

    $scope.lastTighteningProcess = function() {
        $http.get(server+':'+port+'/tighteningprocesses/last')
            .success(function (response) {
                $scope.tighteningprocess = response;
            })
            .error(function () {
                $scope.error = 'could not load tightening process.';
            });
    }

    $scope.notificationFilter = '';

    $scope.findNotifications = function() {
        $scope.synchtimestamp = new Date().getTime();
        $http.get(server+':'+port+'/unread')
            .success(function (response) {
                $scope.notifications = response;
            })
            .error(function () {
                $scope.error = 'could not load notifications.';
            });
    }

    $http.get('https://predix-tracktracedashboard.run.aws-usw02-pr.ice.predix.io/getMachineNotification')
        .success(function (response) {
            $scope.notifications = response;
        })
        .error(function () {
            $scope.error = 'could not load notifications.';
        });


    $scope.acknowledgeNotification = function (notification) {

        notification.acknowledged = "true";
        console.log(notification);

        $http.put(server+':'+port+'/notifications/'+notification._id, notification)
           .success(function(status) {
                // this callback will be called asynchronously
                // when the response is available
                console.log(status)
            })
            .error(function(error) {
                // called asynchronously if an error occurs
                // or server returns response with an error status.
                console.log(error)
            });
    }

    $scope.toggleNotifications = function (type) {
        $scope.notificationLowClass = {'opacity':'0.2'};
        $scope.notificationMediumClass = {'opacity':'0.2'};
        $scope.notificationHighClass = {'opacity':'0.2'};

        if (type=='low') {
            $scope.notificationLowClass = {'opacity':'1'};
        }
        else if (type=='medium') {
            $scope.notificationMediumClass = {'opacity':'1'};
        }
        else if (type=='high'){
            $scope.notificationHighClass = {'opacity':'1'};
        }
        // Toggle -> Remove Filter
        if ($scope.notificationFilter == type) {
            $scope.notificationFilter = "";
            $scope.notificationLowClass = {'opacity':'1'};
            $scope.notificationMediumClass = {'opacity':'1'};
            $scope.notificationHighClass = {'opacity':'1'};
        } else
            $scope.notificationFilter = type;

    }


    $scope.applyNvd3Data = function(){
        /* Inspired by Lee Byron's test data generator. */
        function _stream_layers(n, m, o) {
            if (arguments.length < 3) o = 0;
            function bump(a) {
                var x = 1 / (.1 + Math.random()),
                    y = 2 * Math.random() - .5,
                    z = 10 / (.1 + Math.random());
                for (var i = 0; i < m; i++) {
                    var w = (i / m - y) * z;
                    a[i] += x * Math.exp(-w * w);
                }
            }
            return d3.range(n).map(function() {
                var a = [], i;
                for (i = 0; i < m; i++) a[i] = o + o * Math.random();
                for (i = 0; i < 5; i++) bump(a);
                return a.map(function(d, i) {
                    return {x: i, y: Math.max(0, d)};
                });
            });
        }


        function testData(stream_names, pointsCount) {
            var now = new Date().getTime(),
                day = 1000 * 60 * 60 * 24, //milliseconds
                daysAgoCount = 60,
                daysAgo = daysAgoCount * day,
                daysAgoDate = now - daysAgo,
                pointsCount = pointsCount || 45, //less for better performance
                daysPerPoint = daysAgoCount / pointsCount;
            return _stream_layers(stream_names.length, pointsCount, .1).map(function(data, i) {
                return {
                    //key: stream_names[i],
                    values: data.map(function(d,j){
                        return {
                            x: daysAgoDate + d.x * day * daysPerPoint,
                            y: Math.floor(d.y * 50) //just a coefficient,
                        }
                    })
                };
            });
        }

        function oeeData() {
            var graphData = [];
            //{x: [1,2,3,4,5,6,7,8,9,10,11], y: [95 ,0 ,88 ,90,85,74,80,87,90, 95,93]}
            var start_date = new Date() - 7*60*60*1000*24;
            graphData.push({x: new Date() - 7*60*60*1000*24, y: 95});
            graphData.push({x: new Date() - 6*60*60*1000*24, y: 95});
            graphData.push({x: new Date() - 5*60*60*1000*24, y: 87});
            graphData.push({x: new Date() - 4*60*60*1000*24, y: 88});
            graphData.push({x: new Date() - 3*60*60*1000*24, y: 90});
            graphData.push({x: new Date() - 2*60*60*1000*24, y: 85});
            graphData.push({x: new Date() - 1*60*60*1000*24, y: 74});
            graphData.push({x: new Date(), y: 80});
            //graphData.push({x: new Date(49*60*60*1000*24), y: 80});
            return [
                {
                    values: graphData,      //values - represents the array of {x,y} data points
                    key: 'OEE (%)', //key  - the name of the series.
                    color: '#82DFD6'  //color - optional: choose your own line color.
                }

            ];

        }

        function defectRateData() {
            var graphData = [];
            //{x: [1,2,3,4,5,6,7,8,9,10,11], y: [95 ,0 ,88 ,90,85,74,80,87,90, 95,93]}
            var start_date = new Date() - 7*60*60*1000*24;
            graphData.push({x: new Date() - 7*60*60*1000*24, y: 4});
            graphData.push({x: new Date() - 6*60*60*1000*24, y: 5});
            graphData.push({x: new Date() - 5*60*60*1000*24, y: 13});
            graphData.push({x: new Date() - 4*60*60*1000*24, y: 5});
            graphData.push({x: new Date() - 3*60*60*1000*24, y: 1});
            graphData.push({x: new Date() - 2*60*60*1000*24, y: 3});
            graphData.push({x: new Date() - 1*60*60*1000*24, y: 5});
            graphData.push({x: new Date(), y: 1});
            //graphData.push({x: new Date(49*60*60*1000*24), y: 2});
            return [
                {
                    values: graphData,      //values - represents the array of {x,y} data points
                    key: 'Defect Rate (%)', //key  - the name of the series.
                    color: '#82DFD6'  //color - optional: choose your own line color.
                }

            ];
        }

        $scope.nvd31Chart = nv.models.lineChart()
            .useInteractiveGuideline(true)
            .margin({left: 28, bottom: 30, right: 0})
            .color(['#82DFD6', '#ddd']);

        $scope.nvd31Chart.xAxis
            //.axisLabel('Week')
            .showMaxMin(false)
            .ticks(0)
            .tickFormat(function(d) { return d3.time.format('%b %d')(new Date(d)); })

        $scope.nvd31Chart.yAxis
            // .axisLabel('OEE (%)')
            .showMaxMin(false)
            .ticks(4);

        $scope.nvd31Data = oeeData();

        $scope.nvd32Chart = nv.models.multiBarChart()
            .margin({left: 28, bottom: 30, right: 0})
            .showYAxis(true)
            .showLegend(false)
            .color(['#F7653F', '#ddd']);


        $scope.nvd32Chart.xAxis
            .showMaxMin(false)
            .ticks(1000)
            .tickFormat(function(d) { return d3.time.format('%b %d')(new Date(d)) });

        $scope.nvd32Chart.yAxis
            .showMaxMin(false)
            .ticks(0)
            .tickFormat(d3.format(',f'))

        $scope.nvd32Data = defectRateData();
        /*
         testData(['', ''], 10).map(function(el, i){
         el.area = true;
         return el;
         });
         */
    };

    scriptLoader.loadScripts([
        'vendor/d3/d3.min.js',
        'vendor/nvd3/nv.d3.min.js'
    ])
        .then(function(){
            $scope.applyNvd3Data()
        });


}]);
