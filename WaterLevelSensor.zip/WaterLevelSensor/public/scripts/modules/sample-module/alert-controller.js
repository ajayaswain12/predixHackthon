define(['angular', './sample-module'], function(angular, sampleModule) {
    'use strict';
    return sampleModule.controller('alertCtrl', ['$scope', 'alertService', function($scope, alertService) {
		$scope.iconname = "fa fa-exclamation-triangle icon";
		$scope.containerHeading = 'Level 1';
		$scope.containerHeadingDate = '09-21-2016 01:28:00 PM EST';
		$scope.containerHeadingDataOne = 'Tank Filling is in process';
		$scope.containerHeadingDataTwo = 'is in Proces';
		$scope.data_show = false;
       alertService.getAlert().then(function(result) {
    	   debugger;
    	   $scope.alertsData=[];
    	   for(var i=0; i < result.length; i++){
    		   
    		   var obj={};
    		   
    		   obj.opportunityNumber="Level: "+result[i].dataPoint;
    		   if(result[i].dataPoint == '8' )
    			   obj.opportunityName = "Tank is full";
    		   else if(result[i].dataPoint == '1')
    			   obj.opportunityName = "Tank is empty";
    		   obj.alertDate = result[i].seriesTimeStamp,
    		   obj.approvedStatus= null;
    		   $scope.alertsData.push(obj);
    	   }
		   
	   });
		for (var key in $scope.alertsData) {								
			if ($scope.alertsData[key].opportunityNumber == oppNumber)  {						       	
						$scope.alertsData[key].selected = true;
					}  else{ $scope.alertsData[key].selected = false; }

		}	
		alertService.getAlertDetail().then(function(result) {
				$scope.result = result;
			   console.log($scope.result[0].alertId)
	   });
		
		
		$scope.selected = null;
		$scope.alertDetails = function(id, result){
			$scope.selected = id;
			$scope.containerHeading = result.opportunityNumber;
			$scope.containerHeadingDate = result.seriesTimeStamp;
			if($scope.dataPoint == '8' ){
				$scope.containerHeadingDataOne = "Tank already filled up";
			}else if($scope.dataPoint == '1' ){
				$scope.containerHeadingDataOne = "Tank is filling up";
			}
			$scope.data_show = true;
			$scope.id = id + 1;
			$scope.alertLst = result;
		};
    }]);
});
