define(['angular', './sample-module'], function (angular, sampleModule) {
    'use strict';
   
    sampleModule.factory('alertService', ['$http', '$q', function ($http, $q) {
		return {
		
			getAlert: function () {
                var deferred = $q.defer();
                $http.get('https://gaswatertimeserieslatest.run.aws-usw02-pr.ice.predix.io/services/gasleakservices/notification')
                    .then(function (res) {
                        deferred.resolve(res.data);
                    },
                    function () {
                        deferred.reject('Error fetching decks with tags');
                    });
                return deferred.promise;
            },
			getAlertDetail: function () {
                var deferred = $q.defer();
                $http.get('https://gaswatertimeserieslatest.run.aws-usw02-pr.ice.predix.io/services/gasleakservices/notification')
                    .then(function (res) {
                        deferred.resolve(res.data);
                    },
                    function () {
                        deferred.reject('Error fetching decks with tags');
                    });
                return deferred.promise;
            }

        };
		
    }]);
});

