define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('DashboardsCtrl', ['$scope', '$log', 'PredixAssetService', 'PredixViewService', function ($scope, $log, PredixAssetService, PredixViewService) {

        PredixAssetService.getAssetsByParentId('root').then(function (initialContext) {
            $scope.initialContexts = initialContext;
        }, function (message) {
            $log.error(message);
        });

        $scope.decks = [];
        $scope.selectedDeckUrl = null;

        // callback for when the Open button is clicked
        $scope.openContext = function (contextDetails) {

            // need to clean up the context details so it doesn't have the infinite parent/children cycle,
            // which causes problems later (can't interpolate: {{context}} TypeError: Converting circular structure to JSON)
            var newContext = angular.copy(contextDetails);
            newContext.children = [];
            newContext.parent = [];

            newContext.url="https://gaswatertimeserieslatest.run.aws-usw02-pr.ice.predix.io/services/gasleakservices/yearly_data/sensor_id/water-reading-1";
            newContext.type="water";
            
            newContext.contextName="Water levels";
            $scope.context = newContext;

            //Tag string can be classification from contextDetails
            PredixViewService.getDecksByTags(newContext.classification) // gets all decks for this context
                .then(function (decks) {
                    $scope.decks = [];

                    if(decks && decks.length > 0) {
                        decks.forEach(function (deck) {
                            $scope.decks.push({name: deck.title, url: PredixViewService.getUrlForFetchingCardsForDeckId(deck.id)});
                            console.log($scope.decks)
                        });
                        $scope.selectedDeckUrl = $scope.decks[0].url;
                    }
                });
        };

        $scope.getChildren = function (parent, options) {
            return PredixAssetService.getAssetsByParentId(parent.id, options);
        };

        $scope.handlers = {
            itemOpenHandler: $scope.openContext,
            getChildren: $scope.getChildren,
            itemClickHandler: $scope.clickHandler
        };
     
           
    	//TABLE start
    	$scope.firstTable = [{'paddesg':'COT -E1','gib': '25110064','accessroads': '04/27/2012','padComplete': '04/27/2012'},
    	                     {'paddesg':'COT -E2','gib': '25110065','accessroads': '05/28/2012','padComplete': '05/02/2012'}];
    	
    	
    }]);
});
