define(['./searchController'], function() {

});
