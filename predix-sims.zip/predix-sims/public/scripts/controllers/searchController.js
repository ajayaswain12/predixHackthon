/**
 * Renders all the widgets on the tab and triggers the datasources that are used by the widgets.
 * Customize your widgets by:
 *  - Overriding or extending widget API methods
 *  - Changing widget settings or options
 */
/* jshint unused: false */
define(['angular',
    'sample-module'
], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('fileCtrl', ['$scope','$rootScope','$log','$http','$location', function ($scope, $rootScope, $log, $http, $location) {

 $scope.filterSearch=function(con){



    if($scope.searchText === undefined){



        return true;



    }



    else{



        if(con.pages.toLowerCase().indexOf($scope.searchText.toLowerCase())!== -1 ){



             return true;



        }



    }



     return false;



};



 $scope.file = {};

   $scope.fileerror = '';

  console.log('hello to file');
       var fileObject = {



                                    fileName : $scope.file.fileName,



                                    header : $scope.file.header



                                }
                                var fileParams = JSON.stringify(fileObject);
                                $http(

                                        {



                                            method : 'POST',



                                            url : 'https://pdfupload-download-service.run.aws-usw02-pr.ice.predix.io/view/getPdfParserDetailsWithFilter',

                                            

                                            data : fileParams,

                                            headers : {



                                                'Content-Type' : 'application/json'



                                            }

                                        })
                                .then(
                                            function(data) {

                                                 $scope.file = data.data;
                                                  console.log(JSON.stringify($scope.file));
 
                                                if(data.data.status=="200"){
                                                    
                                                }
                                                else{
                                                    $scope.fileerror = ' failed.';
                                                }
                                                

                                            },
                                            function(error) {

                                                console.log(error);

                                                $scope.fileerror = 'failed';
                                                
                                            
                                            });
 $scope.reloadPage = function(){window.location.reload();}




    }]);
});
