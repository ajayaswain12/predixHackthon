define(['angular',

    'sample-module'

], function (angular, controllers) {

    'use strict';

controllers.controller("nameCtrl", ['$scope', '$http', '$timeout', '$window',    
        function ($scope, $http, $location, $timeout, $window) {    
            $scope.AttachStatus = "";    
    
$scope.fnUpload = function () {  
            var fd = new FormData()  
            for (var i in $scope.files) {  
                fd.append("uploadedFile", $scope.files[i])  
            }  
            var xhr = new XMLHttpRequest();  
            xhr.addEventListener("load", uploadComplete, false);  
            xhr.open("POST", "https://pdfupload-download-service.run.aws-usw02-pr.ice.predix.io/upload", true);  
            $scope.progressVisible = true;  
            xhr.send(fd);  
        }  
  
        function uploadComplete(evt) {  
            $scope.progressVisible = false;  
            if (evt.target.status == 201) {  
                $scope.FilePath = evt.target.responseText;  
                $scope.AttachStatus = "Upload Done";  
                alert($scope.FilePath);  
            }  
            else {  
                $scope.AttachStatus = evt.target.responseText;  
            }  
        } 


}    
    ]);



/*
.controller('nameCtrl', ['$scope', 'fileUpload', function($scope, fileUpload){
    
    $scope.uploadFile = function(){
        var file = $scope.myFile;
        console.log('file is ' );
        console.dir(file);
        var uploadUrl ="https://pdfupload-download-service.run.aws-usw02-pr.ice.predix.io/upload";
        fileUpload.uploadFileToUrl(file, uploadUrl);
    };
    
}]);*/
})


