/** global angular, require */
/**
 * Load controllers, directives, filters, services before bootstrapping the application.
 * NOTE: These are named references that are defined inside of the config.js RequireJS configuration file.
 */
define([
    'jquery',
    'angular',
    'main',
    'routes',
    'interceptors',
    'px-datasource'
], function ($, angular) {
    'use strict';

    /**
     * Application definition
     * This is where the AngularJS application is defined and all application dependencies declared.
     * @type {module}
     */
    var predixApp = angular.module('predixApp', [
        'app.routes',
        'app.interceptors',
        'sample.module',
        'predix.datasource'
    ]);

    /**
     * Main Controller
     * This controller is the top most level controller that allows for all
     * child controllers to access properties defined on the $rootScope.
     */
    predixApp.controller('MainCtrl', ['$scope', '$rootScope', function ($scope, $rootScope) {

        //Global application object
        window.App = $rootScope.App = {
            version: '1.0',
            name: 'Engine Shop Visit',
            session: {},
            tabs: [
                {icon: 'fa-home', state: 'about', label: 'Home'},
                {icon: 'fa-tachometer', /*state: 'Shipment Creation', */label: 'Shipment Creation'},
                {icon: 'fa-tachometer', /*state: 'PO', */label: 'PO'},
                {icon: 'fa-tachometer', /*state: 'Demand',*/ label: 'Demand and Lead Time', subitems: [
                    {state: 'search-Planned-Orders', label: 'Search Planned Orders'}
                ]},
                {icon: 'fa-tachometer', /*state: 'Scorecard',*/label:'Scorecard'},
                {icon: 'fa-tachometer', /*state: 'Reports',*/ label: 'Reports'},
                {icon: 'fa-tachometer', state: 'Logout', label: 'Logout'}
            ]
        };

    }]);


    //Set on window for debugging
    window.predixApp = predixApp;

    //Return the application  object
    return predixApp;
});
